package com.dealova.hijaiyah;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
